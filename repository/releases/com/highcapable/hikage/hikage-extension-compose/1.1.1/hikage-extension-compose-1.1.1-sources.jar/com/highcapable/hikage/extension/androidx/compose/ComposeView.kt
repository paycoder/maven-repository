/*
 * Hikage - A real-time Android View runtime powered by Kotlin DSL.
 * Copyright (C) 2019 HighCapable
 * https://github.com/BetterAndroid/Hikage
 *
 * Apache License Version 2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * This file is created by fankes on 2025/2/28.
 */
@file:Suppress("unused", "FunctionName")
@file:JvmName("ComposeViewPerformer")

package com.highcapable.hikage.extension.androidx.compose

import android.view.ViewGroup
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import com.highcapable.hikage.annotation.Hikagable
import com.highcapable.hikage.core.Hikage
import com.highcapable.hikage.core.attribute.HikageAttribute
import com.highcapable.hikage.core.base.HikageView
import com.highcapable.hikage.core.layout.LayoutParams
import com.highcapable.hikage.core.layout.View

/**
 * Composable in [Hikage].
 *
 * Usage:
 *
 * ```kotlin
 * Hikagable {
 *    ComposeView(
 *        lparams = LayoutParams(matchParent = true)
 *    ) {
 *        Text("Hello, Compose in Hikage!")
 *    }
 * }
 * ```
 * @see ComposeView
 * @see Hikage.Performer.View
 */
@Hikagable
fun <LP : ViewGroup.LayoutParams> Hikage.Performer<LP>.ComposeView(
    lparams: LayoutParams? = null,
    id: String? = null,
    attrs: HikageAttribute = {},
    init: HikageView<ComposeView> = {},
    content: (@Composable () -> Unit)? = null
) {
    View(
        viewClass = ComposeView::class,
        factory = { context, attrs -> ComposeView(context, attrs) },
        lparams = lparams,
        id = id,
        attrs = attrs
    ) {
        setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindowOrReleasedFromPool)

        init(this)
        content?.let { setContent(it) }
    }
}