/*
 * Gropify - A type-safe and modern properties plugin for Gradle.
 * Copyright (C) 2019 HighCapable
 * https://github.com/HighCapable/Gropify
 *
 * Apache License Version 2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * This file is created by fankes on 2025/10/13.
 */
package com.highcapable.gropify.plugin.generator.config

import com.highcapable.gropify.debug.error
import com.highcapable.gropify.plugin.Gropify
import com.palantir.javapoet.JavaFile
import com.squareup.kotlinpoet.FileSpec
import java.io.File
import java.io.IOException

/**
 * Source code specification.
 */
internal class SourceCodeSpec(val type: Type, private val codeSpec: Any) {

    /**
     * Source code type.
     */
    enum class Type {
        Java,
        Kotlin
    }

    /**
     * Writes the source code to the specified directory.
     * @param directory the target directory.
     */
    @Throws(IOException::class)
    fun writeTo(directory: File) {
        when (codeSpec) {
            is JavaFile -> codeSpec.writeTo(directory)
            is FileSpec -> codeSpec.writeTo(directory)
            else -> Gropify.error("Unsupported code specification type: ${codeSpec.javaClass.name}")
        }
    }
}